import "./right-panel.css";

export default function RightPanel() {
  return (
    <aside className="right-panel">
      {/* Placeholder for future use */}
      <div className="right-panel-inner">
        {/* Intentionally empty for now */}
      </div>
    </aside>
  );
}

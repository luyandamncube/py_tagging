import { NavLink } from "react-router-dom";
import "./sidebar.css";

type Props = {
  open?: boolean;
  onClose?: () => void;
  mobile?: boolean;
};

export default function Sidebar({ open = true, onClose, mobile }: Props) {
  return (
    <aside className={`sidebar ${mobile ? "mobile" : ""} ${open ? "open" : ""}`}>
      <div className="sidebar-header">Tagger</div>

      <nav className="sidebar-nav">
        <NavLink
          to="/intake"
          className={({ isActive }) =>
            `nav-item ${isActive ? "active" : ""}`
          }
          onClick={onClose}
        >
          Bulk Intake
        </NavLink>

        <NavLink
          to="/review"
          className="nav-item"
        >
          Review
        </NavLink>

        <NavLink
          to="/search"
          className="nav-item disabled"
        >
          Search
        </NavLink>
      </nav>
    </aside>
  );
}

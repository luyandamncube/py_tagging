from pydantic import BaseModel
from typing import List, Optional
from uuid import UUID

class ContentCreate(BaseModel):
    url: str
    site: str
    creator: Optional[str]
    type: str

class TagCreate(BaseModel):
    id: str
    label: str
    category: str

class TagCreate(BaseModel):
    id: str
    label: str
    category: str
    group_id: str
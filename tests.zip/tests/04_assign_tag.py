"""
Smoke test: assign a tag to the most recent content.
"""

import requests

API_BASE = "http://localhost:8000"


def main():
    # 1. Get content
    resp = requests.get(f"{API_BASE}/debug/content")
    resp.raise_for_status()
    rows = resp.json()

    if not rows:
        raise RuntimeError("❌ No content found. Run 01_create_content.py first.")

    latest = rows[-1]
    content_id = latest[0]

    payload = {
        "content_id": content_id,
        "tag_ids": ["niche:fitness"],
    }

    url = f"{API_BASE}/tags/assign"

    print(f"🔗 Assigning tag to content {content_id}")

    resp = requests.post(url, json=payload)
    resp.raise_for_status()

    print("✅ Tag assigned successfully")


if __name__ == "__main__":
    main()
